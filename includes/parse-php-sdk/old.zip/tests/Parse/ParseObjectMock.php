<?php
/**
 * Class ParseObjectMock | Parse/Test/ParseObjectMock.php
 */

namespace Parse\Test;

use Parse\ParseObject;

class ParseObjectMock extends ParseObject
{

}
