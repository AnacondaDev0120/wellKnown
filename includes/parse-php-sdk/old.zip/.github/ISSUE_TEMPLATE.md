### Issue Description

~~ Please put your description here. Also indicate what's happening vs. what you expect to happen ~~

### Steps to reproduce

~~ Please provide the necessary steps here to reproduce this when possible ~~

### Environment Details

- Your PHP Version: **[your version here]**
- Your Parse PHP SDK Version: **[your version here]**
- Your Operating System: **[your OS here]**
- VM (only if you're running something like HHVM): **PHP**

### Logs/Traces

~~ Include any relevant logs/traces here ~~
